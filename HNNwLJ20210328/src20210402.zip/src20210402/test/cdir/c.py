
from bdir.b import b

class c:
    def __init__(self):
        print('c')
        print('c make b')
        B = b()
