
from adir.a import a

class b:
    def __init__(self):
        print('b')
        print('b make a')
        A = a()
