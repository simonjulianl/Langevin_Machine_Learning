from adir.a import a
from bdir.b import b
from cdir.c import c

if __name__=='__main__':

    A = a()
    B = b()
    C = c()
