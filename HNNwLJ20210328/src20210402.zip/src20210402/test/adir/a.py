
from .a1 import a1

class a:
    def __init__(self):
        print('a')
        print('a make a1')
        A1 = a1()
