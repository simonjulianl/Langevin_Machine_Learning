

class a1:
    def __init__(self):
        print('a1 ')
